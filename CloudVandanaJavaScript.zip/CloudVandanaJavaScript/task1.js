// Quest - 1 Take a sentence as an input and reverse every word in that sentence.    (JAVASCRIPT)

function reverseWords(sentence) {
    const words = sentence.split(" ");
    const reversedWords = words.map(word => {
      return word.split("").reverse().join("");
    });
    return reversedWords.join(" ");
  }
  
  const sentence = "This is a sunny day ";
  const reversedSentence = reverseWords(sentence);
  console.log(reversedSentence);