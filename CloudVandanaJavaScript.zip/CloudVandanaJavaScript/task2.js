// Quest - 2  Perform sorting of an array in descending order.    (JAVASCRIPT)

const arr = [5, 2, 8, 1, 9];
arr.sort((a, b) => b - a);
console.log(arr);