package code;

public class cv3 {
	
	// Quest - 3 Check if the input is pangram or not. (Pangram is a sentence that contains all the alphabets from
	// a-z)
	
	 public static boolean isPangram(String sentence) {
	        boolean[] alphabet = new boolean[26];
	        int count = 0;
	        
	        for (int i = 0; i < sentence.length(); i++) {
	            char c = sentence.charAt(i);
	            if (Character.isLetter(c)) {
	                int index = Character.toLowerCase(c) - 'a';
	                if (!alphabet[index]) {
	                    alphabet[index] = true;
	                    count++;
	                }
	            }
	        }
	        
	        return count == 26;
	    }

	public static void main(String[] args) {
    
		
	      String sentence = " We promptly judged antique ivory buckles for the prize";
	      String sentence1 = "The quick brown fox jumps over the lazy dog";
	        boolean isPangram = isPangram(sentence);
	        boolean isPangram1 = isPangram(sentence1);
	        System.out.println(isPangram);
	        System.out.println(isPangram1);
		
		
		
		   
		    
		    
		  
		 
		
		
		

	}

}
