package code;
import java.util.HashMap;

public class cv2 {
	
	// Ques - 2 Enter Roman Number as input and convert it to integer. (ex IX = 9)
	
	 public static int romanToInt(String romanNumeral) {
	        HashMap<Character, Integer> romanMap = new HashMap<>();
	        romanMap.put('I', 1);
	        romanMap.put('V', 5);
	        romanMap.put('X', 10);
	        romanMap.put('L', 50);
	        romanMap.put('C', 100);
	        romanMap.put('D', 500);
	        romanMap.put('M', 1000);
	        
	        int result = 0;
	        int previousValue = 0;
	        
	        for (int i = romanNumeral.length() - 1; i >= 0; i--) {
	            int currentValue = romanMap.get(romanNumeral.charAt(i));
	            
	            if (currentValue >= previousValue) {
	                result += currentValue;
	            } else {
	                result -= currentValue;
	            }
	            
	            previousValue = currentValue;
	        }
	        
	        return result;
	    }

	public static void main(String[] args) {
		

        String romanNumeral = "IX";
        int integer = romanToInt(romanNumeral);
        System.out.println(integer);
		
	

		
		   
		    
		  
		 
		
		
		
	}

}
